from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # Declare launch arguments
    motor_service_address_arg = DeclareLaunchArgument(
        'motor_service_address',
        default_value='localhost:50201',
        description='Address of the RPIMotorService gRPC service'
    )
    
    # Get launch configurations
    motor_service_address = LaunchConfiguration('motor_service_address')
    
    # Create node descriptions
    motor_adapter_node = Node(
        package='omni_control',
        executable='motor_adapter',
        name='motor_adapter',
        parameters=[{
            'motor_service_address': motor_service_address,
        }],
        output='screen'
    )
    
    # Return the launch description
    return LaunchDescription([
        motor_service_address_arg,
        motor_adapter_node,
    ]) 