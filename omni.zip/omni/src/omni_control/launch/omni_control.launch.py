from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # Declare launch arguments
    wheel_radius_arg = DeclareLaunchArgument(
        'wheel_radius',
        default_value='0.05',
        description='Wheel radius in meters'
    )
    
    robot_radius_arg = DeclareLaunchArgument(
        'robot_radius',
        default_value='0.15',
        description='Robot radius (distance from center to wheel) in meters'
    )
    
    max_wheel_speed_arg = DeclareLaunchArgument(
        'max_wheel_speed',
        default_value='5.0',
        description='Maximum wheel speed in rad/s'
    )
    
    kp_arg = DeclareLaunchArgument(
        'kp',
        default_value='1.0',
        description='Proportional gain for PID controller'
    )
    
    ki_arg = DeclareLaunchArgument(
        'ki',
        default_value='0.1',
        description='Integral gain for PID controller'
    )
    
    kd_arg = DeclareLaunchArgument(
        'kd',
        default_value='0.05',
        description='Derivative gain for PID controller'
    )
    
    noise_level_arg = DeclareLaunchArgument(
        'noise_level',
        default_value='0.01',
        description='Noise level for simulation'
    )
    
    # Get launch configurations
    wheel_radius = LaunchConfiguration('wheel_radius')
    robot_radius = LaunchConfiguration('robot_radius')
    max_wheel_speed = LaunchConfiguration('max_wheel_speed')
    kp = LaunchConfiguration('kp')
    ki = LaunchConfiguration('ki')
    kd = LaunchConfiguration('kd')
    noise_level = LaunchConfiguration('noise_level')
    
    # Create node descriptions
    controller_node = Node(
        package='omni_control',
        executable='controller',
        name='omni_controller',
        parameters=[{
            'wheel_radius': wheel_radius,
            'robot_radius': robot_radius,
            'max_wheel_speed': max_wheel_speed,
            'kp': kp,
            'ki': ki,
            'kd': kd,
        }],
        output='screen'
    )
    
    simulator_node = Node(
        package='omni_control',
        executable='simulator',
        name='omni_robot_sim',
        parameters=[{
            'wheel_radius': wheel_radius,
            'robot_radius': robot_radius,
            'max_wheel_speed': max_wheel_speed,
            'noise_level': noise_level,
        }],
        output='screen'
    )
    
    # Return the launch description
    return LaunchDescription([
        wheel_radius_arg,
        robot_radius_arg,
        max_wheel_speed_arg,
        kp_arg,
        ki_arg,
        kd_arg,
        noise_level_arg,
        controller_node,
        simulator_node,
    ]) 