#!/usr/bin/env python3

import math
import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Vector3
from std_msgs.msg import Float64MultiArray
from nav_msgs.msg import Odometry

class OmniController(Node):
    """
    A ROS2 node for controlling a 3-wheeled omnidirectional robot.
    
    This controller takes a Twist command as input and calculates the required
    wheel velocities to achieve the desired motion. It uses closed-loop control
    to adjust wheel speeds based on the error between desired and actual position.
    """
    
    def __init__(self):
        super().__init__('omni_controller')
        
        # Declare parameters
        self.declare_parameter('wheel_radius', 0.05)  # meters
        self.declare_parameter('robot_radius', 0.15)  # meters from center to wheel
        self.declare_parameter('max_wheel_speed', 5.0)  # rad/s
        self.declare_parameter('kp', 1.0)  # Proportional gain
        self.declare_parameter('ki', 0.1)  # Integral gain
        self.declare_parameter('kd', 0.05)  # Derivative gain
        
        # Get parameters
        self.wheel_radius = self.get_parameter('wheel_radius').value
        self.robot_radius = self.get_parameter('robot_radius').value
        self.max_wheel_speed = self.get_parameter('max_wheel_speed').value
        self.kp = self.get_parameter('kp').value
        self.ki = self.get_parameter('ki').value
        self.kd = self.get_parameter('kd').value
        
        # Wheel configuration for a 3-wheeled omnidirectional robot
        # Each wheel is positioned 120 degrees apart
        # The angles represent the direction of positive wheel rotation
        self.wheel_angles = [0, 2*math.pi/3, 4*math.pi/3]  # radians
        
        # Create the inverse kinematics matrix
        self.ik_matrix = self._build_inverse_kinematics_matrix()
        
        # Initialize PID controller variables
        self.error_sum = np.zeros(3)  # Integral term [vx, vy, omega]
        self.last_error = np.zeros(3)  # For derivative term
        
        # Robot state
        self.current_position = np.zeros(3)  # [x, y, theta]
        self.current_velocity = np.zeros(3)  # [vx, vy, omega]
        self.setpoint = np.zeros(3)  # [x, y, theta]
        self.setpoint_velocity = np.zeros(3)  # [vx, vy, omega]
        
        # Publishers and subscribers
        self.wheel_cmd_pub = self.create_publisher(
            Float64MultiArray, 'wheel_velocities', 10)
        
        self.setpoint_sub = self.create_publisher(
            Twist, 'cmd_vel', 10)
        
        self.odom_sub = self.create_subscription(
            Odometry, 'odom', self.odom_callback, 10)
        
        self.cmd_vel_sub = self.create_subscription(
            Twist, 'cmd_vel', self.cmd_vel_callback, 10)
        
        # Control loop timer
        self.timer = self.create_timer(0.01, self.control_loop)  # 100Hz control loop
        
        self.get_logger().info('Omni Controller started')
    
    def _build_inverse_kinematics_matrix(self):
        """Build the inverse kinematics matrix for the 3-wheeled robot."""
        matrix = np.zeros((3, 3))
        for i, angle in enumerate(self.wheel_angles):
            # Row for each wheel, columns for [vx, vy, omega]
            matrix[i, 0] = -math.sin(angle)  # x component
            matrix[i, 1] = math.cos(angle)   # y component
            matrix[i, 2] = self.robot_radius  # rotational component
        
        # Scale by wheel radius to get angular velocity
        return matrix / self.wheel_radius
    
    def odom_callback(self, msg):
        """Update the current robot state from odometry."""
        # Extract position and orientation
        self.current_position[0] = msg.pose.pose.position.x
        self.current_position[1] = msg.pose.pose.position.y
        
        # Convert quaternion to Euler angles (just extract yaw)
        # This is a simplified conversion assuming small roll and pitch
        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w
        
        # Yaw (theta) from quaternion
        self.current_position[2] = math.atan2(2.0 * (qw * qz + qx * qy), 
                                           qw * qw + qx * qx - qy * qy - qz * qz)
        
        # Extract linear and angular velocities
        self.current_velocity[0] = msg.twist.twist.linear.x
        self.current_velocity[1] = msg.twist.twist.linear.y
        self.current_velocity[2] = msg.twist.twist.angular.z
    
    def cmd_vel_callback(self, msg):
        """Receive velocity commands."""
        # Update the velocity setpoint
        self.setpoint_velocity[0] = msg.linear.x
        self.setpoint_velocity[1] = msg.linear.y
        self.setpoint_velocity[2] = msg.angular.z
        
        self.get_logger().info(f'Received cmd_vel: [{msg.linear.x}, {msg.linear.y}, {msg.angular.z}]')
    
    def control_loop(self):
        """Main control loop to compute wheel velocities."""
        # Calculate the error between setpoint velocity and current velocity
        velocity_error = self.setpoint_velocity - self.current_velocity
        
        # PID control
        # P term
        p_term = self.kp * velocity_error
        
        # I term - accumulate error
        self.error_sum += velocity_error * 0.01  # dt = 0.01s (100Hz)
        i_term = self.ki * self.error_sum
        
        # D term
        d_term = self.kd * (velocity_error - self.last_error) / 0.01
        self.last_error = velocity_error.copy()
        
        # Combined control output
        control_output = p_term + i_term + d_term
        
        # Map desired robot velocity to wheel velocities using inverse kinematics
        wheel_velocities = np.dot(self.ik_matrix, control_output)
        
        # Apply velocity limits
        wheel_velocities = np.clip(wheel_velocities, -self.max_wheel_speed, self.max_wheel_speed)
        
        # Publish wheel velocities
        msg = Float64MultiArray()
        msg.data = wheel_velocities.tolist()
        self.wheel_cmd_pub.publish(msg)
        
        self.get_logger().debug(f'Wheel velocities: {wheel_velocities}')

def main(args=None):
    rclpy.init(args=args)
    controller = OmniController()
    rclpy.spin(controller)
    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main() 