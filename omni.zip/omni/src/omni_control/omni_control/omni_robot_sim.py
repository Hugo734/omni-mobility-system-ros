#!/usr/bin/env python3

import math
import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
from std_msgs.msg import Float64MultiArray
from nav_msgs.msg import Odometry
import tf2_ros
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import Quaternion, Point, Vector3, PointStamped
from builtin_interfaces.msg import Time
from rcl_interfaces.msg import ParameterDescriptor, ParameterType

class OmniRobotSimulation(Node):
    """
    A ROS2 node that simulates a 3-wheeled omnidirectional robot.
    
    This node subscribes to wheel velocity commands and simulates the robot's movement,
    publishing odometry information.
    """
    
    def __init__(self):
        super().__init__('omni_robot_simulation')
        
        # Declare and get parameters (same as controller to ensure consistency)
        self.declare_parameter('wheel_radius', 0.05)  # meters
        self.declare_parameter('robot_radius', 0.15)  # meters from center to wheel
        self.declare_parameter('max_wheel_speed', 5.0)  # rad/s
        self.declare_parameter('noise_level', 0.01)  # Noise level for simulation
        
        # Get parameters
        self.wheel_radius = self.get_parameter('wheel_radius').value
        self.robot_radius = self.get_parameter('robot_radius').value
        self.max_wheel_speed = self.get_parameter('max_wheel_speed').value
        self.noise_level = self.get_parameter('noise_level').value
        
        # Wheel configuration for a 3-wheeled omnidirectional robot
        # Each wheel is positioned 120 degrees apart
        self.wheel_angles = [0, 2*math.pi/3, 4*math.pi/3]  # radians
        
        # Create the forward kinematics matrix
        self.fk_matrix = self._build_forward_kinematics_matrix()
        
        # Robot state
        self.position = np.zeros(3)  # [x, y, theta]
        self.velocity = np.zeros(3)  # [vx, vy, omega]
        self.wheel_velocities = np.zeros(3)  # [w1, w2, w3]
        
        # Publishers and subscribers
        self.odom_pub = self.create_publisher(Odometry, 'odom', 10)
        
        self.wheel_vel_sub = self.create_subscription(
            Float64MultiArray, 'wheel_velocities', self.wheel_vel_callback, 10)
        
        # TF2 broadcaster for robot frame
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # Simulation timer
        self.sim_timer = self.create_timer(0.01, self.simulation_step)  # 100Hz simulation
        self.sim_time = 0.0  # Simulation time in seconds
        
        self.get_logger().info('Omni Robot Simulation started')
    
    def _build_forward_kinematics_matrix(self):
        """Build the forward kinematics matrix for the 3-wheeled robot."""
        # The forward kinematics matrix is the transpose of the inverse kinematics matrix
        # multiplied by a scaling factor (wheel radius)
        matrix = np.zeros((3, 3))
        for i, angle in enumerate(self.wheel_angles):
            # Column for each wheel, rows for [vx, vy, omega]
            matrix[0, i] = -math.sin(angle)  # x component
            matrix[1, i] = math.cos(angle)   # y component
            matrix[2, i] = 1.0 / self.robot_radius  # rotational component
        
        # Scale by wheel radius
        return matrix * self.wheel_radius / 3.0  # Normalize by number of wheels
    
    def wheel_vel_callback(self, msg):
        """Receive wheel velocity commands."""
        # Update wheel velocities from command
        for i in range(min(3, len(msg.data))):
            self.wheel_velocities[i] = msg.data[i]
        
        self.get_logger().debug(f'Received wheel velocities: {self.wheel_velocities}')
    
    def simulation_step(self):
        """Update the simulation state."""
        dt = 0.01  # Time step (100Hz)
        self.sim_time += dt
        
        # Calculate robot velocity from wheel velocities using forward kinematics
        self.velocity = np.dot(self.fk_matrix, self.wheel_velocities)
        
        # Add some noise to simulate real-world conditions
        noise = np.random.normal(0, self.noise_level, 3)
        self.velocity += noise
        
        # Update position based on velocity
        # For the x and y components, we need to consider the robot's orientation
        # For rotation, we simply integrate the angular velocity
        self.position[0] += (self.velocity[0] * math.cos(self.position[2]) - 
                             self.velocity[1] * math.sin(self.position[2])) * dt
        self.position[1] += (self.velocity[0] * math.sin(self.position[2]) + 
                             self.velocity[1] * math.cos(self.position[2])) * dt
        self.position[2] += self.velocity[2] * dt
        
        # Normalize angle to [-pi, pi]
        self.position[2] = math.atan2(math.sin(self.position[2]), math.cos(self.position[2]))
        
        # Publish odometry
        self._publish_odometry()
    
    def _publish_odometry(self):
        """Publish odometry information and TF transformation."""
        # Create odometry message
        odom_msg = Odometry()
        current_time = self.get_clock().now()
        odom_msg.header.stamp = current_time.to_msg()
        odom_msg.header.frame_id = 'odom'
        odom_msg.child_frame_id = 'base_link'
        
        # Set position
        odom_msg.pose.pose.position.x = self.position[0]
        odom_msg.pose.pose.position.y = self.position[1]
        odom_msg.pose.pose.position.z = 0.0
        
        # Set orientation (convert yaw to quaternion)
        quat = self._yaw_to_quaternion(self.position[2])
        odom_msg.pose.pose.orientation = quat
        
        # Set velocity
        odom_msg.twist.twist.linear.x = self.velocity[0]
        odom_msg.twist.twist.linear.y = self.velocity[1]
        odom_msg.twist.twist.angular.z = self.velocity[2]
        
        # Publish odometry
        self.odom_pub.publish(odom_msg)
        
        # Publish TF transformation
        self._publish_tf(current_time)
    
    def _publish_tf(self, time):
        """Publish TF transformation between odom and base_link frames."""
        tf_msg = TransformStamped()
        tf_msg.header.stamp = time.to_msg()
        tf_msg.header.frame_id = 'odom'
        tf_msg.child_frame_id = 'base_link'
        
        # Set translation
        tf_msg.transform.translation.x = self.position[0]
        tf_msg.transform.translation.y = self.position[1]
        tf_msg.transform.translation.z = 0.0
        
        # Set rotation
        tf_msg.transform.rotation = self._yaw_to_quaternion(self.position[2])
        
        # Broadcast transform
        self.tf_broadcaster.sendTransform(tf_msg)
    
    def _yaw_to_quaternion(self, yaw):
        """Convert yaw angle to quaternion."""
        quat = Quaternion()
        quat.x = 0.0
        quat.y = 0.0
        quat.z = math.sin(yaw / 2)
        quat.w = math.cos(yaw / 2)
        return quat

def main(args=None):
    rclpy.init(args=args)
    simulator = OmniRobotSimulation()
    rclpy.spin(simulator)
    simulator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main() 