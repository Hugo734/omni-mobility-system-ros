#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64

import grpc
import numpy as np
import threading
import time

# Importamos los módulos generados por protobuf
from omni_control.rpi_motor_pb2 import StateRequest
from omni_control.rpi_motor_pb2_grpc import RPIMotorStub

class MotorAdapter(Node):
    """
    Nodo adaptador que recibe comandos ROS2 y los envía al servicio 
    RPIMotorService a través de gRPC.
    """
    
    def __init__(self):
        super().__init__('motor_adapter')
        
        # Declaramos parámetros
        self.declare_parameter('motor_service_address', 'localhost:50201')
        
        # Obtenemos la dirección del servicio de motor
        self.motor_service_address = self.get_parameter('motor_service_address').value
        
        # Creamos un canal gRPC
        self.channel = grpc.insecure_channel(self.motor_service_address)
        
        # Creamos el stub para comunicarnos con el servicio
        self.stub = RPIMotorStub(self.channel)
        
        # Suscripciones
        self.cmd_vel_sub = self.create_subscription(
            Twist, 'cmd_vel', self.cmd_vel_callback, 10)
        
        self.pitch_sub = self.create_subscription(
            Float64, 'pitch', self.pitch_callback, 10)
        
        self.heave_sub = self.create_subscription(
            Float64, 'heave', self.heave_callback, 10)
        
        self.leds_sub = self.create_subscription(
            Float64, 'leds', self.leds_callback, 10)
        
        # Estado actual
        self.vel_x = 0.0
        self.vel_y = 0.0
        self.vel_yaw = 0.0
        self.vel_heave = 0.0
        self.pitch = 0.0
        self.leds = 0.0
        
        # Último tiempo de envío
        self.last_send_time = time.time()
        
        # Timer para enviar periódicamente los comandos al servicio
        self.timer = self.create_timer(0.05, self.send_command)  # 20Hz
        
        self.get_logger().info('Motor Adapter started, connecting to: ' + self.motor_service_address)
    
    def cmd_vel_callback(self, msg):
        """Procesa los mensajes de cmd_vel."""
        self.vel_x = msg.linear.x
        self.vel_y = msg.linear.y
        self.vel_yaw = msg.angular.z
        self.get_logger().debug(f'Received cmd_vel: [{self.vel_x}, {self.vel_y}, {self.vel_yaw}]')
    
    def pitch_callback(self, msg):
        """Procesa los mensajes de pitch."""
        self.pitch = msg.data
        self.get_logger().debug(f'Received pitch: {self.pitch}')
    
    def heave_callback(self, msg):
        """Procesa los mensajes de heave."""
        self.vel_heave = msg.data
        self.get_logger().debug(f'Received heave: {self.vel_heave}')
    
    def leds_callback(self, msg):
        """Procesa los mensajes de leds."""
        self.leds = msg.data
        self.get_logger().debug(f'Received leds: {self.leds}')
    
    def send_command(self):
        """Envía el comando actual al servicio RPIMotorService."""
        try:
            # Creamos la solicitud con los valores actuales
            request = StateRequest(
                vel_x=self.vel_x,
                vel_y=self.vel_y,
                vel_yaw=self.vel_yaw,
                vel_heave=self.vel_heave,
                pitch=self.pitch,
                leds=self.leds
            )
            
            # Enviamos la solicitud al servicio
            response = self.stub.SetState(request)
            
            # Verificamos la respuesta
            if response.res:
                # Éxito
                pass
            else:
                # Error
                self.get_logger().warning('Failed to set motor state')
            
            # Actualizamos el tiempo de último envío
            self.last_send_time = time.time()
            
        except Exception as e:
            self.get_logger().error(f'Error sending command to motor service: {e}')

def main(args=None):
    rclpy.init(args=args)
    adapter = MotorAdapter()
    rclpy.spin(adapter)
    adapter.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main() 