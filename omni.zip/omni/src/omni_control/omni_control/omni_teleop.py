#!/usr/bin/env python3

import math
import sys
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import threading
import termios
import tty

msg = """
Control Your Omnidirectional Robot!
---------------------------
Moving around:
        w    
   a    s    d
        x    

w/x : increase/decrease linear velocity (X axis)
a/d : increase/decrease linear velocity (Y axis)
q/e : increase/decrease angular velocity (Z axis)

s : force stop

CTRL-C to quit
"""

# Key mappings
moveBindings = {
    'w': (1, 0, 0),    # Forward
    'x': (-1, 0, 0),   # Backward
    'a': (0, 1, 0),    # Left
    'd': (0, -1, 0),   # Right
    'q': (0, 0, 1),    # Rotate CCW
    'e': (0, 0, -1),   # Rotate CW
    's': (0, 0, 0),    # Stop
}

class OmniTeleop(Node):
    """
    A ROS2 node for teleoperation of an omnidirectional robot.
    
    This node reads keyboard input and publishes Twist messages to control
    the robot's movement.
    """
    
    def __init__(self):
        super().__init__('omni_teleop')
        
        # Publisher for velocity commands
        self.vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Velocity state
        self.linear_x = 0.0
        self.linear_y = 0.0
        self.angular_z = 0.0
        
        # Parameters
        self.declare_parameter('linear_speed_increment', 0.1)  # m/s
        self.declare_parameter('angular_speed_increment', 0.2)  # rad/s
        self.declare_parameter('max_linear_speed', 1.0)  # m/s
        self.declare_parameter('max_angular_speed', 2.0)  # rad/s
        self.declare_parameter('publish_rate', 10.0)  # Hz
        
        # Get parameters
        self.linear_speed_increment = self.get_parameter('linear_speed_increment').value
        self.angular_speed_increment = self.get_parameter('angular_speed_increment').value
        self.max_linear_speed = self.get_parameter('max_linear_speed').value
        self.max_angular_speed = self.get_parameter('max_angular_speed').value
        self.publish_rate = self.get_parameter('publish_rate').value
        
        # Timer for publishing velocity commands
        self.timer = self.create_timer(1.0 / self.publish_rate, self.publish_cmd_vel)
        
        self.get_logger().info('Omni Teleop started')
        self.get_logger().info(msg)
    
    def publish_cmd_vel(self):
        """Publish velocity command."""
        # Create Twist message
        twist = Twist()
        twist.linear.x = self.linear_x
        twist.linear.y = self.linear_y
        twist.angular.z = self.angular_z
        
        # Publish velocity command
        self.vel_pub.publish(twist)
    
    def process_key(self, key):
        """Process keyboard input."""
        if key in moveBindings.keys():
            x, y, z = moveBindings[key]
            if x != 0:
                # Update linear.x velocity
                self.linear_x += self.linear_speed_increment * x
                self.linear_x = max(-self.max_linear_speed, min(self.max_linear_speed, self.linear_x))
            elif y != 0:
                # Update linear.y velocity
                self.linear_y += self.linear_speed_increment * y
                self.linear_y = max(-self.max_linear_speed, min(self.max_linear_speed, self.linear_y))
            elif z != 0:
                # Update angular.z velocity
                self.angular_z += self.angular_speed_increment * z
                self.angular_z = max(-self.max_angular_speed, min(self.max_angular_speed, self.angular_z))
            else:
                # Stop
                self.linear_x = 0.0
                self.linear_y = 0.0
                self.angular_z = 0.0
            
            # Log current velocity
            self.get_logger().info(f'Current velocity: linear X: {self.linear_x:.2f}, linear Y: {self.linear_y:.2f}, angular Z: {self.angular_z:.2f}')
        else:
            # Unknown key - do nothing
            pass

def get_key(settings):
    """Get keyboard input."""
    tty.setraw(sys.stdin.fileno())
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def main(args=None):
    # Initialize ROS
    rclpy.init(args=args)
    teleop = OmniTeleop()
    
    # Save terminal settings
    settings = termios.tcgetattr(sys.stdin)
    
    # Create a separate thread for ROS spinning
    def spin_thread():
        rclpy.spin(teleop)
    
    thread = threading.Thread(target=spin_thread, daemon=True)
    thread.start()
    
    try:
        while rclpy.ok():
            key = get_key(settings)
            
            # Check for Ctrl+C
            if key == '\x03':
                break
            
            teleop.process_key(key)
    except Exception as e:
        teleop.get_logger().error(f'Exception in teleop: {e}')
    finally:
        # Restore terminal settings
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        
        # Cleanup
        teleop.destroy_node()
        rclpy.shutdown()
        thread.join()

if __name__ == '__main__':
    main() 