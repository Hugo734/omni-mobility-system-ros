# Omnidirectional Robot Control

A ROS2 package to control a 3-wheeled omnidirectional robot with closed-loop control.

## Overview

This package provides nodes for:
- Controller: Implements inverse kinematics and closed-loop control to convert velocity commands to wheel velocities
- Simulator: Simulates the dynamics of a 3-wheeled omnidirectional robot
- Teleop: Keyboard-based teleoperation for testing

The controller uses a PID controller to adjust wheel velocities based on desired velocity setpoints.

## Installation

Clone this repository into your ROS2 workspace:

```bash
cd ~/your_ros2_ws/src
git clone https://github.com/yourusername/omni_control.git
cd ..
colcon build --symlink-install
source install/setup.bash
```

## Usage

### Launch All Nodes

To launch the controller and simulator together:

```bash
ros2 launch omni_control omni_control.launch.py
```

### Run Teleop

```bash
ros2 run omni_control teleop
```

### Parameters

The following parameters can be configured via the launch file or at runtime:

**Controller and Simulator:**
- `wheel_radius`: Wheel radius in meters (default: 0.05)
- `robot_radius`: Distance from robot center to wheel in meters (default: 0.15)
- `max_wheel_speed`: Maximum wheel speed in rad/s (default: 5.0)

**Controller Only:**
- `kp`: Proportional gain (default: 1.0)
- `ki`: Integral gain (default: 0.1)
- `kd`: Derivative gain (default: 0.05)

**Simulator Only:**
- `noise_level`: Standard deviation of simulated noise (default: 0.01)

**Teleop:**
- `linear_speed_increment`: Linear velocity increment per keypress (default: 0.1)
- `angular_speed_increment`: Angular velocity increment per keypress (default: 0.2)
- `max_linear_speed`: Maximum linear speed (default: 1.0)
- `max_angular_speed`: Maximum angular speed (default: 2.0)

## Control Keys

The teleop node uses the following keys:
- `w/x`: Increase/decrease linear velocity along X axis
- `a/d`: Increase/decrease linear velocity along Y axis
- `q/e`: Increase/decrease angular velocity
- `s`: Stop all movement
- `Ctrl+C`: Quit

## Mathematical Model

### Inverse Kinematics

For a 3-wheeled omnidirectional robot with wheels at angles θ₁=0°, θ₂=120°, θ₃=240°, the inverse kinematics matrix maps robot velocity to wheel velocities:

```
[w₁]   [ -sin(θ₁)   cos(θ₁)   R ]   [vx]
[w₂] = [ -sin(θ₂)   cos(θ₂)   R ] × [vy]
[w₃]   [ -sin(θ₃)   cos(θ₃)   R ]   [ω ]
```

Where:
- w₁, w₂, w₃ are wheel velocities (rad/s)
- vx, vy are robot linear velocities (m/s)
- ω is robot angular velocity (rad/s)
- R is the robot radius (m)

### Forward Kinematics

The simulator uses forward kinematics to convert wheel velocities to robot velocity:

```
[vx]   [ -sin(θ₁)  -sin(θ₂)  -sin(θ₃) ]   [w₁]
[vy] = [  cos(θ₁)   cos(θ₂)   cos(θ₃) ] × [w₂]
[ω ]   [   1/R       1/R       1/R    ]   [w₃]
```

## Topics

- `/cmd_vel` (geometry_msgs/Twist): Velocity commands
- `/wheel_velocities` (std_msgs/Float64MultiArray): Wheel velocity commands
- `/odom` (nav_msgs/Odometry): Robot odometry

## License

This project is licensed under the MIT License - see the LICENSE file for details. 